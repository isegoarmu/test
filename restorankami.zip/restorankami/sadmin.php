<?php 
include("koneksi.php"); 
$id = $_POST['id_petugas'];
$nama = $_POST['nama_petugas'];
$jenkel = $_POST['jenkel'];
$username = $_POST['txtusername']; 
$password = $_POST['txtpassword']; 
$sql = "insert into petugas (id_petugas,nama_petugas,jenkel,username,password) values ('$id','$nama','$jenkel','$username','$password')"; 
$proses = mysqli_query($koneksi,$sql);
if ($proses) {
header("location:index.php");
}
