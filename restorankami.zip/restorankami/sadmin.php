<?php 
include("koneksi.php"); 
$id = $_POST['id_petugas']; 
$nama = $_POST['nama_petugas']; 
$jenkel = $_POST['jenkel']; 
$username = $_POST['txtusername']; 
$password = $_POST['txtpassword']; 
$simpan = mysqli_query($koneksi, "insert into petugas values 
('$id','$nama','$jenkel','$username','$password')"); 
if ($simpan) { 
header("location:petugas.php"); 
} 