<?php
include('koneksi.php');

$id = $_POST['id_pelanggan'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$alamat = $_POST['alamat'];
$tlp = $_POST['tlp'];
$sql = "UPDATE pelanggan SET nama_pelanggan='$nama_pelanggan', alamat='$alamat', tlp='$tlp' WHERE id_pelanggan='$id'";
$simpan = mysqli_query($koneksi, $sql);
if ($simpan) {
    header("location:pelanggan.php?pesan=Berhasil Ubah Data!");
}
?>
