<?php
// koneksi database
include 'koneksi.php';

// menangkap data yang di kirim dari form
$id = $_POST['id'];
$nama = $_POST['nama'];
$jenkel = $_POST['jenkel'];
$username = $_POST['txtusername'];
$password = $_POST['txtpassword'];

// update data ke database
$sql = "UPDATE petugas SET nama_petugas='$nama', jenkel='$jenkel', username='$username',Password='$password' WHERE id_petugas='$id'";

if (mysqli_query($koneksi, $sql)) {
    // mengalihkan halaman kembali ke petugas.php jika berhasil
    header("location: petugas.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>
