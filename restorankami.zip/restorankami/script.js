document.addEventListener('DOMContentLoaded', function() {
    const orderForm = document.getElementById('orderForm');
    const orderTableBody = document.querySelector('#orderTable tbody');
    const saveBtn = document.getElementById('saveBtn');
    const resetBtn = document.getElementById('resetBtn');

    orderForm.addEventListener('submit', function(event) {
        event.preventDefault();
        saveOrder();
    });

    resetBtn.addEventListener('click', function() {
        resetForm();
    });

    // Fetch all orders
    fetchOrders();

    function fetchOrders() {
        fetch('api.php')
            .then(response => response.json())
            .then(data => {
                renderOrders(data);
            });
    }

    function renderOrders(orders) {
        orderTableBody.innerHTML = '';
        for (const order of orders) {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.id}</td>
                <td>${order.qty}</td>
                <td>${order.customerId}</td>
                <td>${order.orderDate}</td>
                <td>${order.tableNumber}</td>
                <td>
                    <button class="editBtn" data-id="${order.id}">Edit</button>
                    <button class="deleteBtn" data-id="${order.id}">Delete</button>
                </td>
            `;
            orderTableBody.appendChild(row);
        }

        // Attach event listeners to edit and delete buttons
        const editBtns = document.getElementsByClassName('editBtn');
        const deleteBtns = document.getElementsByClassName('deleteBtn');

        for (const editBtn of editBtns) {
            editBtn.addEventListener('click', function() {
                const orderId = this.getAttribute('data-id');
                fetchOrderById(orderId);
            });
        }

        for (const deleteBtn of deleteBtns) {
            deleteBtn.addEventListener('click', function() {
                const orderId = this.getAttribute('data-id');
                deleteOrder(orderId);
            });
        }
    }

    function fetchOrderById(orderId) {
        fetch(`api.php?id=${orderId}`)
            .then(response => response.json())
            .then(order => {
                fillForm(order);
            });
    }

    function saveOrder() {
        const formData = new FormData(orderForm);
        const orderId = formData.get('orderId');

        let url = 'api.php';
        let method = 'POST';
        if (orderId) {
            url += `?id=${orderId}`;
            method = 'PUT';
        }

        fetch(url, {
            method: method,
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                resetForm();
                fetchOrders();
            }
        });
    }

    function deleteOrder(orderId) {
        fetch(`api.php?id=${orderId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                fetchOrders();
            }
        });
    }

    function fillForm(order) {
        document.getElementById('orderId').value = order.id;
        document.getElementById('qty').value = order.qty;
        document.getElementById('customerId').value = order.customerId;
        document.getElementById('orderDate').value = order.orderDate;
        document.getElementById('tableNumber').value = order.tableNumber;
    }

    function resetForm() {
        document.getElementById('orderId').value = '';
        document.getElementById('qty').value = '';
        document.getElementById('customerId').value = '';
        document.getElementById('orderDate').value = '';
        document.getElementById('tableNumber').value = '';
    }
});
