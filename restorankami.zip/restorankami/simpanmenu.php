<?php 
include("koneksi.php"); 
$id = $_POST['idmenu']; 
$nama = $_POST['nama']; 
$kategori = $_POST['kategori']; 
$harga = $_POST['harga']; 
$simpan = mysqli_query($koneksi, "insert into menu values 
('$id','$nama','$kategori','$harga')"); 
if ($simpan) { 
header("location:menuu.php"); 
} 