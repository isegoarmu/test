<?php
 include("koneksi.php");
 $id_menu= $_POST['id_menu'];
 $nama_menu = $_POST['nama_menu'];
 $kategori = $_POST['kategori'];
 $harga = $_POST['harga'];
$sql = "insert into menu values ('$id_menu','$nama_menu','$kategori','$harga')";
 $proses  = mysqli_query($koneksi, $sql);
 if ($proses) {
 header("location:index.php");
 }