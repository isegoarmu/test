<html> 
 
<head> 
<title></title> 
    <?php include("layout/header.php"); ?> 
</head> 
 
 <body> 
     
 <?php 
 if (isset($_GET['error'])) { 
    echo "<p style='color:red;'>" . $_GET['error'] . "</p>"; 
    } 
 
 session_start(); 
 if (!isset($_SESSION['username'])) { 
 header("location:login.php"); 
 } 
 
 ?> 
 <div class="container"> 
 <div class="row"> 
            <div class="col-md-8 mx-auto"> 
                 
 
 <h4>Tambah Data  Petugas </h4> 
 <form action="simpan_petugas.php" method="POST" enctype="multipart/form-data"> 
 <div class="mb-3"> 
                        ID Petugas 
                        <input type="text" class="form-control" name="idpetugas"> 
                    </div> 
                <div class="mb-3"> 
                   Nama Petugas
                    <input type="text" class="form-control" name="nama"> 
                </div> 
                <div class="mb-3"> 
                 Jenis Kelamin
                    <input type="text" class="form-control" name="jenkel"> 
                </div> 
                <div class="mb-3"> 
                   Username
                    <input type="text" class="form-control" name="txtusername"> 
                </div> 
                <div class="mb-3"> 
                   Password
                    <input type="text" class="form-control" name="txtpassword"> 
                </div> 
                <button type="submit" class="btn btn-primary">Simpan</button> 
                </form> 
            </div> 
        </div> 
    </div> 
 <br> 
 </form> 
 <?php include("layout/bottom.php");?> 
 </body> 
 </html>