<?php 
include("koneksi.php"); 
$id_menu = $_POST['id_menu']; 
$nama_menu = $_POST['nama_menu']; 
$kategori = $_POST['kategori']; 
$harga = $_POST['harga']; 
$simpan = mysqli_query($koneksi, "insert into menu values 
('$id','$nama','$kategori','$harga')"); 
if ($simpan) { 
header("location:menu.php"); 
} 