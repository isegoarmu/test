<?php
include('koneksi.php');

if(isset($_POST['simpan'])){
    $insert = mysqli_query($koneksi, "INSERT INTO menu VALUES (
        '".$_POST['id_menu']."',
        '".$_POST['nama_menu']."',
        '".$_POST['kategori']."',
        '".$_POST['harga']."'
    )");

    if($insert){
        echo "Berhasil disimpan";
    } else {
        echo "Gagal ditampilkan";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Halaman input biodata</title>
</head>
<body>
    <h3>MASUKKAN MENU</h3>
    <a href="index.php" style="padding: 0.4% 0.8%; background-color: red; color: yellow; border-radius: 2px; text-decoration: none;">MASUKKAN MENU</a><br><br>
    <form action="menu.php" method="POST">
        <table>
            <tr>
                <td>ID MENU :</td>
                <td><input type="text" name="id_menu" placeholder="ID menu" required></td>
            </tr>
            <tr>
                <td>NAMA MENU :</td>
                <td><input type="text" name="nama_menu" placeholder="Nama menu" required></td>
            </tr>
            <tr>
                <td>KATEGORI :</td>
                <td><input type="text" name="kategori" placeholder="Kategori" required></td>
            </tr>
            <tr>
                <td>HARGA :</td>
                <td><input type="text" name="harga" placeholder="Harga" required></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><input type="submit" name="simpan" value="Simpan"></td>
            </tr>
        </table>
    </form>
</body>
</html>
