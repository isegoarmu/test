<?php
// koneksi database
include 'koneksi.php';

// menangkap data yang di kirim dari form
$id = $_POST['id'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$telephone = $_POST['telephone'];
// update data ke database
$sql = "UPDATE pelanggan SET nama_pelanggan='$nama', alamat='$alamat', tlp='$telephone' WHERE id_pelanggan='$id'";

if (mysqli_query($koneksi, $sql)) {
    // mengalihkan halaman kembali ke petugas.php jika berhasil
    header("location: pelanggan.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>
