<!doctype html> 
<html lang="en"> 
<head> 
<title>Halaman Petugas</title> 

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="anak.css">
<?php include("layout/header.php"); ?> 
</head>  
<body> 
<?php include("layout/menu.php"); ?> 
<?php 
session_start(); 
if (!isset($_SESSION['username'])) { 
header("location:login.php"); 
} 
if (isset($_GET['pesan'])) { 
echo $_GET['pesan']; 
} 
?> 
<table class="table"> 
<tr> 
<th>No.</th> 
<th>ID Petugas</th>
<th>Nama Petugas</th>
<th>Jenkel</th>
<th>Username</th> 
<th>Password</th> 
<th>Aksi</th>

</tr> 
<?php
include('koneksi.php'); 
$no = 1; 
$sql = "select * from petugas"; 
$aksi = mysqli_query($koneksi, $sql); 
while ($data = mysqli_fetch_assoc($aksi)) { 
?> 
<tr> 
<td><?php echo $no; ?></td> 
<td><?php echo $data['id_petugas']; ?></td> 
<td><?php echo $data['nama_petugas']; ?></td> 
<td><?php echo $data['jenkel']; ?></td> 
<td><?php echo $data['username']; ?></td>
<td><?php echo $data['password']; ?></td>  
<td> 

<a href="upetugas.php?x=<?php echo $data['id_petugas']; ?>">
<span class="material-symbols-outlined">
draw
</span>
    </a>
    <a href="hapuspetugas.php?x=<?php echo $data['id_petugas']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">
    <span class="material-symbols-outlined">
privacy_tip
</span>
                    </a></td>
<style>
    .delete-button {
        border: 1px solid red;
    }
    .edit-button {
        border: 1px solid blue;
    }
</style>
<?php 
$no++; 
} 
?> 

</table>

<a href="admin.php"> <button class="neon-button">Registrasi</button></a><br>
<style>
    
     .neon-button {
        display: inline-block;
        padding: 8px 10px;
        background-image: linear-gradient(to right, rgb(255,0,0),rgb(0,128,128)   );
        cursor: pointer;
        border-radius: 50px;
        text-align: center;
        color: 	#F4A460;
        font-weight: bold;
        text-decoration: none;
        text-transform: uppercase;
        letter-spacing: 2px;
        border: 1px solid white;
    }

    .neon-button:hover {
        animation: glow 2s linear infinite;
    }

    @keyframes glow {
        0% {
            box-shadow: 5px 5px 20px rgb(255, 0, 255), -5px -5px 20px rgb(255, 0, 255);
        }
    }
</style>
<?php include("layout/header.php"); ?>
</body>
<?php include("layout/bottom.php"); ?> 
</body> 
</html>

