<!doctype html> 
<html lang="en"> 
<head> 
<link rel="stylesheet" href="crud.css">
<title>Halaman Petugas</title> 
<?php include("layout/header.php"); ?> 
</head>  
<body> 
<?php include("layout/menu.php"); ?> 
<?php 
session_start(); 
if (!isset($_SESSION['username'])) { 
header("location:login.php"); 
} 
if (isset($_GET['pesan'])) { 
echo $_GET['pesan']; 
} 
?> 
<table class="table"> 
<tr> 
<th>No.</th> 
<th>ID Petugas</th>
<th>Nama Petugas</th>
<th>Jenkel</th>
<th>Username</th> 
<th>Password</th> 
<th>Aksi</th>

</tr> 
<?php
include('koneksi.php'); 
$no = 1; 
$sql = "select * from petugas"; 
$aksi = mysqli_query($koneksi, $sql); 
while ($data = mysqli_fetch_assoc($aksi)) { 
?> 
<tr> 
<td><?php echo $no; ?></td> 
<td><?php echo $data['id_petugas']; ?></td> 
<td><?php echo $data['nama_petugas']; ?></td> 
<td><?php echo $data['jenkel']; ?></td> 
<td><?php echo $data['username']; ?></td>
<td><?php echo $data['password']; ?></td>  
<td> 
<a href="upetugas.php?x=<?php echo $data['id_petugas']; ?>">Edit</a> 
<a href="hapuspetugas.php?x=<?php echo $data['id_petugas']; ?>">Delete</a> 
</td> 
</tr> 
<?php 
$no++; 
} 
?> 
</table> 
<a href="tadmin.php">Tambah Petugas</a><br> 
<?php include("layout/bottom.php"); ?> 
</body> 
</html>

