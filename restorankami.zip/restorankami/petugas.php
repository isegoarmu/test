<!doctype html> 
<html lang="en"> 
<head> 
<title>Halaman Petugas</title> 

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="anak.css">
<link rel="icon" href="image/refranz.png" />
<?php include("layout/header.php"); ?> 
</head>  
<body> 
<?php include("layout/menuku.php"); ?> 
<?php 
session_start(); 
if (!isset($_SESSION['username'])) { 
header("location:login.php"); 
} 
if (isset($_GET['pesan'])) { 
echo $_GET['pesan']; 
} 
?> 
<table border = "1" cellspacing="0" width="300%">
<tr> 
<th><span class="material-symbols-outlined">
123
</span>No.</th> 
<th><span class="material-symbols-outlined">
verified
</span>ID Petugas</th>
<th><span class="material-symbols-outlined">
badge
</span>Nama Petugas</th>
<th><span class="material-symbols-outlined">
transgender
</span>Jenis Kelamin</th>
<th><span class="material-symbols-outlined">
account_box
</span>Username</th> 
<th><span class="material-symbols-outlined">
visibility_lock
</span>Password</th> 
<th><span class="material-symbols-outlined">
menu_book
</span>Opsi</th>

</tr> 
<?php
include('koneksi.php'); 
$no = 1; 
$sql = "select * from petugas"; 
$aksi = mysqli_query($koneksi, $sql); 
while ($data = mysqli_fetch_assoc($aksi)) { 
?> 
<tr> 
<td><?php echo $no; ?></td> 
<td><?php echo $data['id_petugas']; ?></td> 
<td><?php echo $data['nama_petugas']; ?></td> 
<td><?php echo $data['jenkel']; ?></td> 
<td><?php echo $data['username']; ?></td>
<td><?php echo $data['password']; ?></td>  
<td> 

<a href="upetugas.php?x=<?php echo $data['id_petugas']; ?>">
<span class="material-symbols-outlined">
draw
</span>
    </a>
    <a href="hapuspetugas.php?x=<?php echo $data['id_petugas']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">
    <span class="material-symbols-outlined">
privacy_tip
</span>

<a href="admin.php"> <button class="neon-button">Registrasi</button></a><br>
                    </a></td>
<style>
    .delete-button {
        border: 1px solid red;
    }
    .edit-button {
        border: 1px solid blue;
    }
</style>
<?php 
$no++; 
} 
?> 

</table>

<style>
    
     .neon-button {
        display: inline-block;
        padding: 8px 10px;
        background-image: linear-gradient(to right, rgb(255,0,0),rgb(0,128,128)   );
        cursor: pointer;
        border-radius: 50px;
        text-align: center;
        color: 	#F4A460;
        font-weight: bold;
        text-decoration: none;
        text-transform: uppercase;
        letter-spacing: 2px;
        border: 1px solid white;
    }

    .neon-button:hover {
        animation: glow 2s linear infinite;
    }

    @keyframes glow {
        0% {
            box-shadow: 5px 5px 20px rgb(255, 0, 255), -5px -5px 20px rgb(255, 0, 255);
        }
    }
</style>
<?php include("layout/header.php"); ?>
</body>
<?php include("layout/bottom.php"); ?> 
</body> 
</html>

