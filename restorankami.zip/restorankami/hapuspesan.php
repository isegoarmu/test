<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data id yang di kirim dari url
$id_pesan = $_GET['id_pesan'];
 
 
// menghapus data dari database
mysqli_query($koneksi,"delete from pesan where id_pesan='$id_pesan'");
 
// mengalihkan halaman kembali ke index.php
header("location:pesan.php");
 
?>