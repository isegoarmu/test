<?php
include('koneksi.php');

$id = $_POST['id_pesan'];
$id_menu = $_POST['id_menu'];
$qty = $_POST['qty'];
$sub_total = $_POST['sub_total'];
$id_pelanggan = $_POST['id_pelanggan'];
$tgl_pesan = $_POST['tgl_pesan'];
$meja = $_POST['meja'];

$sql = "UPDATE pesan SET id_menu='$id_menu', qty='$qty', sub_total='$sub_total', id_pelanggan='$id_pelanggan', tgl_pesan='$tgl_pesan', meja='$meja' WHERE id_pesan='$id'";

$simpan = mysqli_query($koneksi, $sql);

if ($simpan) {
    header("location: pesan.php?pesan=Berhasil Ubah Data!");
    exit;
} else {
    echo "Error updating data: " . mysqli_error($koneksi);
}

?>