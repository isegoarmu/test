const slider = document.querySelector('.slider');
let isDragging = false;
let startPos = 0;
let currentTranslate = 0;
let prevTranslate = 0;

slider.addEventListener('mousedown', dragStart);
slider.addEventListener('touchstart', dragStart);

slider.addEventListener('mousemove', drag);
slider.addEventListener('touchmove', drag);

slider.addEventListener('mouseup', dragEnd);
slider.addEventListener('touchend', dragEnd);

slider.addEventListener('mouseleave', dragEnd);
slider.addEventListener('touchcancel', dragEnd);

function dragStart(event) {
  event.preventDefault();
  startPos = getPositionX(event);
  isDragging = true;

  // Continuously animate the slider
  requestAnimationFrame(animation);
}

function drag(event) {
  if (isDragging) {
    const currentPosition = getPositionX(event);
    currentTranslate = prevTranslate + currentPosition - startPos;
  }
}

function dragEnd() {
  isDragging = false;
  prevTranslate = currentTranslate;
}

function animation() {
  setSliderPosition();
  if (isDragging) {
    requestAnimationFrame(animation);
  }
}

function getPositionX(event) {
  return event.type.includes('mouse') ? event.pageX : event.touches[0].clientX;
}

function setSliderPosition() {
  slider.style.transform = `translateX(${currentTranslate}px)`;
}
