<?php
include('koneksi.php');

if (isset($_GET['x'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM pelanggan WHERE id_pelanggan = '$id'";
    $delete = mysqli_query($koneksi, $sql);

    if ($delete) {
        header("Location: pelanggan.php?pesan=Data berhasil dihapus!");
        exit;
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
} else {
    header("Location: pelanggan.php");
    exit;
}

mysqli_close($koneksi);
?>
