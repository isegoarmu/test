<?php 
// koneksi database
include 'koneksi.php';

// menangkap data id yang di kirim dari url
$id = $_GET['x'];

// menghapus data dari database
$query = "DELETE FROM menu WHERE id_menu = '$id'";
$result = mysqli_query($koneksi, $query);

// memeriksa apakah query berhasil dijalankan
if ($result) {
    header("location: menuu.php");
} else {
    // menampilkan pesan error jika query gagal
    echo "Gagal menghapus data: " . mysqli_error($koneksi);
}
?>
