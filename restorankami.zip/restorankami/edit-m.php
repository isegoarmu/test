<?php
// koneksi database
include 'koneksi.php';

// menangkap data yang di kirim dari form
$id = $_POST['id'];
$nama = $_POST['namamenu'];
$kategori = $_POST['kategori'];
$harga = $_POST['harga'];

// update data ke database
$sql = "UPDATE menu SET nama_menu='$nama', kategori='$kategori', harga='$harga' WHERE id_menu='$id'";

if (mysqli_query($koneksi, $sql)) {
    // mengalihkan halaman kembali ke petugas.php jika berhasil
    header("location: menuu.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>
