<html> 
 
<head> 
<title></title> 
    <?php include("layout/header.php"); ?> 
    <link rel="icon" href="image/refranz.png" />
    <link rel="stylesheet" href="pesan.css">
</head> 
 
 <body> 
     
 <?php 
 if (isset($_GET['error'])) { 
    echo "<p style='color:red;'>" . $_GET['error'] . "</p>"; 
    } 
 
 session_start(); 
 if (!isset($_SESSION['username'])) { 
 header("location:login.php"); 
 } 
 
 ?> 
 <div class="container"> 
 <div class="row"> 
            <div class="col-md-8 mx-auto"> 
                 
 
 <h4>Tambah Data Pemesanan </h4> 
 <form action="simpanpesan.php" method="POST" enctype="multipart/form-data"> 
 <div class="mb-3"> 
                        ID Pesan 
                        <input type="text" class="form-control" name="id_pesan"> 
                    </div> 
                <div class="mb-3"> 
                   ID Menu
                    <input type="text" class="form-control" name="id_menu"> 
                </div> 
                <div class="mb-3"> 
                 Qty
                    <input type="text" class="form-control" name="qty"> 
                </div> 
                <div class="mb-3"> 
                   Total Sub 
                    <input type="text" class="form-control" name="sub_total"> 
                </div> 
                <div class="mb-3"> 
                   ID Pelanggan
                    <input type="text" class="form-control" name="id_pelanggan"> 
                </div> 
                <div class="mb-3"> 
                 Tanggal Pesan
                    <input type="date" class="form-control" name="tgl_pesan"> 
                </div> 
                <div class="mb-3"> 
                 Meja
                    <input type="text" class="form-control" name="meja"> 
                </div> 
                <button type="submit" class="btn btn-primary">Simpan</button> 
                </form> 
            </div> 
        </div> 
    </div> 
 <br> 
 </form> 
 <?php include("layout/bottom.php");?> 
 </body> 
 </html>