<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Halaman input pesan</title>
</head>
<body>
<h3>MASUKKAN PESANAN</h3>
<a href="index.php" style="padding :0.4% 0.8%;background-color :Red; color :yellow; border-radius: 2px; text-decoration : none;">
PESANAN</a><br><br>
<form action= " " method="POST">
    <table>
        <tr>
            <td>ID PESAN : <br></td>
            <td><input type="text" name="id_pesan" placeholder = "ID PESAN" required></td>
        </tr>
        <tr>
            <td>ID MENU : <br></td>
            <td><input type="text" name="id_menu" placeholder = "ID MENU" required></td>
        </tr>
      
        <tr>
            <td>QUANTITY : <br></td>
            <td><input type="text" name="qty" placeholder = "QUANTITY" required></td>
        </tr>
        
        <tr>
            <td>SUB TOTAL : <br></td>
            <td><input type="text" name="sub_total" placeholder = "SUB TOTAL" required></td>
        </tr>

        <tr>
            <td>ID PELANGGAN : <br></td>
            <td><input type="text" name="id_pelanggan" placeholder = "ID PELANGGAN" required></td>
        </tr>
        
        <tr>
            <td>TANGGAL PESAN : <br></td>
            <td><input type="date" name="tgl_pesan" placeholder = "TANGGAL PESAN" required></td>
        </tr>
        
        <tr>
            <td>MEJA : <br></td>
            <td><input type="text" name="meja" placeholder = "NOMOR MEJA" required></td>
        </tr>

        <tr>
            <td></td>
            <td></td>
            <td><input type="submit" name="simpan" value="simpan"></td>
        </tr>
    </table>
</form>
<?php
include "koneksi.php";
if(isset($_POST['simpan'])){
$insert =mysqli_query($koneksi,"insert into pesan values
                     ('".$_POST['id_pesan']."',
                     '".$_POST['id_menu']."',
                     '".$_POST['qty']."',
                     '".$_POST['sub_total']."',
                     '".$_POST['id_pelanggan']."',
                     '".$_POST['tgl_pesan']."',
                     '".$_POST['meja']."')");
                     if($insert){
                        echo "berhasil disimpan";
                     }else{
                        echo "gagal ditampilkan";
                     }

}?>
</body>
</html>