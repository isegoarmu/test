<!doctype html>
<html lang="en">

<head>
    <link rel="stylesheet" href="login.css">
    <title>Halaman Login</title>
    <?php include("layout/header.php"); ?>
</head>

<body>
    <?php
    if (isset($_GET['error'])) {
        echo "<p style='color:red;'>" . $_GET['error'] . "</p>";
    }
    ?>
    <form action="proses.php" method="POST">
        <div class="login-card-container">
        <div class="login-card">
            <div class="login-card-logo">
                <img src="logo.png" alt="logo">
            </div>
            <div class="login-card-header">
                <h1>LOGIN</h1>
                <div>Silahkan Login</div>
            </div>
            <form class="login-card-form">
                <div class="form-item">
                <form class="login-card-form">
                <div class="form-item">
                        
                    <span class="form-item-icon material-symbols-rounded">Username</span>
                        <input type="text" placeholder="Username" class="form-control" name="txtusername"
                        autofocus required>
                    </div>
                    <div class="mb-3">
                    <span class="form-item-icon material-symbols-rounded">Password</span>
                        <input type="password"  placeholder="Password" class="form-control" name="txtpassword"
                        autofocus required>
                    </div>
                    <div class="form-item-other">
                    <div class="checkbox">
                        <input type="checkbox" id="rememberMeCheckbox" checked>
                        <label for="rememberMeCheckbox">Remember me</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Masuk</button>
                    <p>Daftar Accout.?</p>
                    <p><a href="admin.php" class="btn btn-primary">registrasi akun disini </a></p>
                </form>
                <div class="login-card-social">
            <div>Other Sign-In Options</div>
            <div class="login-card-social-btns">
                <a href="https://www.facebook.com/">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-facebook"
                        width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                        stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3"></path>
                    </svg>
                </a>
                <a href="https://www.google.com/intl/id/gmail/about/">
                    <svg xmlns="https://www.google.com/intl/id/gmail/about/" class="icon icon-tabler icon-tabler-brand-google" width="24"
                        height="24" viewBox="0 0 24 24" stroke-width="3" stroke="currentColor" fill="none"
                        stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <path d="M17.788 5.108a9 9 0 1 0 3.212 6.892h-8"></path>
                    </svg>
                </a>
            </div>
           
        </div>
    </div>

    <?php include("layout/bottom.php"); ?>
</body>
<script src="login.js"></script>
</html>