<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="crud.css">
    <title>MENU</title>
</head>
<body>
	
<div class="container">
		<div class="col-lg-15">
			<div class="page-header">
<h2>PESANMENU</h2>
    <a href="tambahmenu.php" style="padding :0.4% 0.8%;background-color :red; color :pink; border-radius: 3px; text-decoration : none;">
      MENU</a><br><br>
      <table border = "3" cellspacing="0" width="50%">
      <tr style ="text-align : center;font-color : red ; font-weight : bold; background-color : pink;">
    <td>NO</td>
    <td>Id Menu</td>
    <td>Nama Menu</td>
    <td>Kategori</td>
    <td>harga</td>
    <td>opsi</td>
</tr>
<?php
include "koneksi.php";
$no = 1;
$select =mysqli_query($koneksi,"select * from menu");
while ($hasil=mysqli_fetch_array($select)){
    ?>
    <tr align = "center">
     <td><?php echo $no++ ?></td>
     <td><?php echo $hasil['id_menu'] ?></td>
     <td><?php echo $hasil['nama_menu'] ?></td>
     <td><?php echo $hasil['kategori'] ?></td>
     <td><?php echo $hasil['harga'] ?></td>
    <td>
        <a href="editmenu.php?id=<?php echo $hasil['id_menu']?>">edit</a>
        <a href="hapuspesan.php?id=<?php echo $hasil['id_menu']?>">Hapus</a>
    </td>
    </tr>
<?php } ?>
</table>
<a href="login.php" class='btn btn-warning btn-sm'>KELUAR</a>
</body>
</html>