<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REFRAN`Z</title>
    <link rel="stylesheet" href="anak.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
</head>
<body>

    <section id="Home">
        <nav>
            <div class="logo">
                <img src="image/refranz.png">
            </div>

            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="menuu.php">Menu</a></li>
                <li><a href="pelanggan.php">Pelanggan</a></li>
                <li><a href="pesan.php">Pesan</a></li>
                <li><a href="petugas.php">Admin Panel</a></li>
                <li><a href="admin.php">Daftar</a></li>
                <li><a href="login.php">Keluar</a></li>
 
                

                