<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Admin Dashboard</title>


    <!-- Montserrat Font -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="panel.css">
    
<link rel="icon" href="image/refranz.png" />
  </head>
  <body>
    <div class="grid-container">

      <!-- Header -->
      <header class="header">
        <div class="menu-icon" onclick="openSidebar()">
   
      </header>
      <!-- End Header -->

      <!-- Sidebar -->
      <aside id="sidebar">
        <div class="sidebar-title">
          <div class="sidebar-brand">
          <span class="material-symbols-outlined">restaurant_menu</span> REFRAN`Z RESTO
          </div>
          <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
          <li class="sidebar-list-item">
            <a href="index.php" target="_blank">
              <span class="material-icons-outlined">dashboard</span> Dashboard
            </a>
          </li>
          <li class="sidebar-list-item">
            <a href="menuu.php" target="_blank">
              <span class="material-icons-outlined">add_shopping_cart</span> Menu
            </a>
          </li>
          
          <li class="sidebar-list-item">
            <a href="pelanggan.php" target="_blank">
            <span class="material-symbols-outlined">person_add</span>Pelanggan
            </a>
          </li>
          <li class="sidebar-list-item">
            <a href="#" target="_blank">
              <span class="material-icons-outlined">shopping_cart</span> Pesan
            </a>
          </li>
          
          <li class="sidebar-list-item">
            <a href="petugas.php" target="_blank">
            <span class="material-symbols-outlined">diversity_3</span> Pengguna
            </a>
          </li>
          
          <li class="sidebar-list-item">
            <a href="admin.php" target="_blank">
            <span class="material-symbols-outlined">diversity_2</span>Registrasi
          </li>
          
          <li class="sidebar-list-item">
            <a href="login.php" target="_blank">
            <span class="material-symbols-outlined">login</span> Keluar
            </a>
          </li>
        </ul>
      </aside>
    