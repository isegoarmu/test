<?php 
include("koneksi.php"); 
$id_pelanggan = $_POST['id_pelanggan']; 
$nama_pelanggan = $_POST['nama_pelanggan']; 
$alamat = $_POST['alamat']; 
$tlp = $_POST['tlp']; 
$simpan = mysqli_query($koneksi, "insert into pelanggan values 
('$id','$nama','$alamat','$tlp')"); 
if ($simpan) { 
header("location:pelanggan.php"); 
} 