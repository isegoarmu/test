<?php
$host = "localhost"; // database host
$user = "root"; // database username
$password = ""; // database password
$database = "resto"; // database name

// Establishing a connection to the database
$koneksi = mysqli_connect($host, $user, $password, $database);

// Checking the connection
if (!$koneksi) {
    die("Connection failed: " . mysqli_connect_error());
}
?>