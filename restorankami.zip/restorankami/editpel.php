<html> 
 
<head> 
<title></title> 
    <?php include("layout/header.php"); ?> 
</head> 
 
 <body> 
     
 <?php 
 if (isset($_GET['error'])) { 
    echo "<p style='color:red;'>" . $_GET['error'] . "</p>"; 
    } 
 
 session_start(); 
 if (!isset($_SESSION['username'])) { 
 header("location:login.php"); 
 } 
 
 ?> 
 <div class="container"> 
 <div class="row"> 
            <div class="col-md-8 mx-auto"> 
                 
 
 <h4>Ubah Data Pelanggan </h4> 
 <?php
	include 'koneksi.php';
	$id = $_GET['x'];
	$data = mysqli_query($koneksi,"select * from pelanggan where id_pelanggan='$id'");
	while($d = mysqli_fetch_array($data)){
		?>
 <form action="edit-p.php" method="POST" enctype="multipart/form-data"> 
 <div class="mb-3"> 
                        <input type="hidden" class="form-control" name="id" value="<?php echo $d['id_pelanggan'];?>">
    </div>
                        <div class="mb-3"> 
                   Nama Pelanggan
                    <input type="text" class="form-control" name="nama" value="<?php echo $d['nama_pelanggan'];?>">
                </div> 
                <div class="mb-3"> 
                 Alamat
                    <input type="text" class="form-control" name="alamat" value="<?php echo $d['alamat'];?>"> 
                </div> 
                <div class="mb-3"> 
                   Telephone
                    <input type="text" class="form-control" name="telephone" value="<?php echo $d['tlp'];?>"> 
                </div> 
                <button type="submit" class="btn btn-primary">Edit Data</button> 
                </form> 
            </div> 
        </div> 
    </div> 
 <br> 
 </form> 
 <?php
    }
?>
 <?php include("layout/bottom.php");?> 
 </body> 
 </html>