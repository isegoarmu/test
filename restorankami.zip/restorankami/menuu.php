<!doctype html>
<html lang="en">
<head>
    <title>Halaman Menu</title>
    <?php include("layout/menuku.php"); ?>
    <link rel="icon" href="image/refranz.png" />
    <style>
        .delete-button {
            border: 1px solid red;
        }
        .edit-button {
            border: 1px solid blue;
        }
        .neon-button {
            display: inline-block;
        padding: 8px 10px;
        background-image: linear-gradient(to right, rgb(0,128,128), rgb(255,0,25), rgb(1,162,128)   );
        cursor: pointer;
        border-radius: 50px;
        text-align: center;
        color: 	#F4A460;
        font-weight: bold;
        text-decoration: none;
        text-transform: uppercase;
        letter-spacing: 2px;
        border: 1px solid white;
        }
        .neon-button:hover {
            animation: glow 2s linear infinite;
        }
        @keyframes glow {
            0% {
                box-shadow: 5px 5px 20px rgb(93, 52, 168), -5px -5px 20px rgb(93, 52, 168);
            }
            50% {
                box-shadow: 5px 5px 20px rgb(81, 224, 210), -5px -5px 20px rgb(81, 224, 210);
            }
        }
    </style>
</head>
<body>
    <?php include("koneksi.php"); ?>
    <?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("location:login.php");
        exit;
    }
    if (isset($_GET['pesan'])) {
        echo $_GET['pesan'];
    }
    ?>
    
<table border = "1" cellspacing="0" width="300%">
<tr>
            <th><span class="material-symbols-outlined">verified</span>ID Menu</th>
            <th><span class="material-symbols-outlined">restaurant_menu</span>Nama Menu</th>
            <th><span class="material-symbols-outlined">category</span>Kategori</th>
            <th><span class="material-symbols-outlined">payments</span>Harga</th>
            <th><span class="material-symbols-outlined">menu_book</span>Opsi</th>
        </tr>
        <?php
        include('koneksi.php');
        $sql = "SELECT * FROM menu";
        $aksi = mysqli_query($koneksi, $sql);
        while ($data = mysqli_fetch_assoc($aksi)) {
            ?>
            <tr>
                <td><?php echo $data['id_menu']; ?></td>
                <td><?php echo $data['nama_menu']; ?></td>
                <td><?php echo $data['kategori']; ?></td>
                <td><?php echo $data['harga']; ?></td>
                <td>
                    <a href="editmenu.php?x=<?php echo $data['id_menu']; ?>">
                        <button class="edit-button"> 
                        <span class="material-symbols-outlined">verified</span>
                        </button>
                    </a>
                    <a href="hapus-m.php?x=<?php echo $data['id_menu']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">
                        <button class="delete-button">
                        <span class="material-symbols-outlined">auto_delete</span>
                        </button>
                        <a href="tambahmenu.php"><button class="neon-button">Tambah Menu</button></a><br>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
        
  
    </table>
    <?php include("layout/bottom.php"); ?>
</body>
