<!doctype html>
<html lang="en">
<head>
    <title>Halaman Menu</title>
    <?php include("layout/header.php"); ?>
    <style>
        .delete-button {
            border: 1px solid red;
        }
        .edit-button {
            border: 1px solid blue;
        }
        .neon-button {
            display: inline-block;
            padding: 8px 10px;
            background-image: linear-gradient(to right, rgb(18, 194, 233), rgb(196, 113, 237), rgb(246, 79, 89));
            cursor: pointer;
            border-radius: 50px;
            text-align: center;
            color: #fff;
            font-weight: bold;
            text-decoration: none;
            text-transform: uppercase;
            letter-spacing: 2px;
            border: 1px solid white;
        }
        .neon-button:hover {
            animation: glow 2s linear infinite;
        }
        @keyframes glow {
            0% {
                box-shadow: 5px 5px 20px rgb(93, 52, 168), -5px -5px 20px rgb(93, 52, 168);
            }
            50% {
                box-shadow: 5px 5px 20px rgb(81, 224, 210), -5px -5px 20px rgb(81, 224, 210);
            }
        }
    </style>
</head>
<body>
    <?php include("menu.php"); ?>
    <?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("location:login.php");
        exit;
    }
    if (isset($_GET['pesan'])) {
        echo $_GET['pesan'];
    }
    ?>
    <table class="table">
        <tr>
            <th>ID Menu</th>
            <th>Nama Menu</th>
            <th>Kategori</th>
            <th>Harga</th>
        </tr>
        <?php
        include('koneksi.php');
        $sql = "SELECT * FROM menu";
        $aksi = mysqli_query($koneksi, $sql);
        while ($data = mysqli_fetch_assoc($aksi)) {
            ?>
            <tr>
                <td><?php echo $data['id_menu']; ?></td>
                <td><?php echo $data['nama_menu']; ?></td>
                <td><?php echo $data['kategori']; ?></td>
                <td><?php echo $data['harga']; ?></td>
                <td>
                    <a href="editmenu.php?x=<?php echo $data['id_menu']; ?>">
                    <span class="material-symbols-outlined">
add_shopping_cart
</span>
                    </a>
                    <a href="hapus-m.php?x=<?php echo $data['id_menu']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">
                    <span class="material-symbols-outlined">
cancel
</span>
                    </a>
                </td>
            </tr>
            <?php
        }
        ?>
    </table>
    <a href="tambahmenu.php"><button class="neon-button">Tambah Menu</button></a><br>
    <?php include("layout/bottom.php"); ?>
</body>

