<?php
// koneksi database
include 'koneksi.php';

// menangkap data yang di kirim dari form
$id_pesan = $_POST['id_pesan'];
$id_menu = $_POST['id_menu'];
$qty = $_POST['qty'];
$sub_total = $_POST['sub_total'];
$id_pelanggan = $_POST['id_pelanggan'];
$tgl_pesan = $_POST['tgl_pesan'];
$meja = $_POST['meja'];
// update data ke database
$sql = "UPDATE pesan SET id_menu='$id_menu', qty='$qty', sub_total='$sub_total',id_pelanggan='$id_pelanggan',tgl_pesan='$tgl_pesan',meja='$meja' WHERE id_pesan='$id_pesan'";

if (mysqli_query($koneksi, $sql)) {
    // mengalihkan halaman kembali ke petugas.php jika berhasil
    header("location: pesan.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>
