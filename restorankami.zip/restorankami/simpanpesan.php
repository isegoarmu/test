<?php 
include("koneksi.php"); 
$id_pesan = $_POST['id_pesan']; 
$id_menu = $_POST['id_menu']; 
$qty = $_POST['qty']; 
$sub_total = $_POST['sub_total']; 
$id_pelanggan = $_POST['id_pelanggan']; 
$tgl_pesan = $_POST['tgl_pesan']; 
$meja = $_POST['meja']; 
$sql = "INSERT INTO pesan (id_pesan, id_menu, qty, sub_total, id_pelanggan, tgl_pesan, meja) VALUES ('$id_pesan', '$id_menu', '$qty', '$sub_total', '$id_pelanggan', '$tgl_pesan', '$meja')";
$simpan = mysqli_query($koneksi, $sql); 
if ($simpan) { 
    header("location: pesan.php"); 
} else {
    echo "Gagal menyimpan data: " . mysqli_error($koneksi);
}
?>
