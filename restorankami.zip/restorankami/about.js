// Initialize and display the map
function initMap() {
    // Coordinates of the restaurant location
    var restaurantLocation = { lat: 40.7128, lng: -74.0060 };
  
    // Create a map centered at the restaurant location
    var map = new google.maps.Map(document.getElementById("map"), {
      center: restaurantLocation,
      zoom: 15
    });
  
    // Add a marker at the restaurant location
    var marker = new google.maps.Marker({
      position: restaurantLocation,
      map: map,
      title: "Restaurant Location"
    });
  }
  