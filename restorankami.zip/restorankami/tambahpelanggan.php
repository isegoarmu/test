<html> 
 
<head> 
<title></title> 
    <?php include("layout/header.php"); ?>
    <link rel="icon" href="image/refranz.png" /> 
    <link rel="stylesheet" href="tambah.css">
</head> 
 
 <body> 
     
 <?php 
 if (isset($_GET['error'])) { 
    echo "<p style='color:red;'>" . $_GET['error'] . "</p>"; 
    } 
 
 session_start(); 
 if (!isset($_SESSION['username'])) { 
 header("location:login.php"); 
 } 
 
 ?> 
 <div class="container"> 
 <div class="row"> 
            <div class="col-md-8 mx-auto"> 
                 
 
 <h4>Tambah Data Pelanggan</h4> 
 <form action="simpelanggan.php" method="POST" enctype="multipart/form-data"> 
 <div class="mb-3"> 
                        ID Pelanggan
                        <input type="text" class="form-control" name="idpelanggan"> 
                    </div> 
                <div class="mb-3"> 
                   Nama Pelanggan
                    <input type="text" class="form-control" name="nama"> 
                </div> 
                <div class="mb-3"> 
                 Alamat
                    <input type="text" class="form-control" name="alamat"> 
                </div> 
                <div class="mb-3"> 
                   Telephone
                    <input type="text" class="form-control" name="tlp"> 
                </div> 
                <button type="submit" class="btn btn-primary">Simpan</button> 
                </form> 
            </div> 
        </div> 
    </div> 
 <br> 
 </form> 
 <?php include("layout/bottom.php");?> 
 </body> 
 </html>