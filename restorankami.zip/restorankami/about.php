<!DOCTYPE html>
<html>
<head>
    
<link rel="icon" href="image/refranz.png" />
    <title>About Us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 40px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin: 0;
            color: #333;
            text-align: center;
            padding-bottom: 20px;
        }

        form {
            margin-top: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #666;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 3px;
            background-color: #f5f5f5;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
            color: #333;
            transition: box-shadow 0.3s;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.2);
        }

        .form-group textarea {
            resize: vertical;
            height: 120px;
        }

        .form-group button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            background-image: url(image/original.gif);
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Contact Us</h2>
        <form>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="name">Telephone:</label>
                <input type="phone" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="message">Message:</label>
                <textarea id="message" name="message" required></textarea>
            </div>
            <div class="form-group">
                <button type="submit">Send Message</button>
            </div>
        </form>
    </div>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 40px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin: 0;
            color: #333;
            text-align: center;
            padding-bottom: 20px;
        }

        .map-container {
            position: relative;
            overflow: hidden;
            padding-top: 56.25%; /* Aspect ratio 16:9 */
        }

        .map-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 0;
        }
    </style>

    <div class="container">
        <h2>Map</h2>
        <div class="map-container">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127504.56080666815!2d98.98109184133422!3d2.953790400619158!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3031845bc37532f9%3A0x8538114693d8a805!2sPematang%20Siantar%20City%2C%20North%20Sumatra!5e0!3m2!1sen!2sid!4v1688396775351!5m2!1sen!2sid" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>
</body>
</html>
