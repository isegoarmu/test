<!doctype html>
<html lang="en">
<head>
    
<title>PELANGGAN</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="panel.css">
<?php include("layout/header.php"); ?>
</head>
<body>
<?php include("menu.php"); ?>
<?php
session_start();
if (!isset($_SESSION['username'])) {
header("location:login.php");
exit;
}
if (isset($_GET['pesan'])) {
echo $_GET['pesan'];
}
?>
<table class="table">
<tr>
<th>ID Pelanggan</th>
<th>Nama Pelanggan</th>
<th>Alamat</th>
<th>Telepon</th>
</tr>
<?php
include('koneksi.php');
$sql = "SELECT * FROM pelanggan";
$aksi = mysqli_query($koneksi, $sql);
while ($data = mysqli_fetch_assoc($aksi)) {
?>
<tr>
<td><?php echo $data['id_pelanggan']; ?></td>
<td><?php echo $data['nama_pelanggan']; ?></td>
<td><?php echo $data['alamat']; ?></td>
<td><?php echo $data['tlp']; ?></td>
<td>
<a href="editpel.php?x=<?php echo $data['id_pelanggan']; ?>">
<span class="material-symbols-outlined">
verified
</span>
    </a>
    <a href="hapus-p.php?x=<?php echo $data['id_pelanggan']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">
    <span class="material-symbols-outlined">
release_alert
</span>
                    </a></td>
<style>
    .delete-button {
        border: 1px solid red;
    }
    .edit-button {
        border: 1px solid blue;
    }
</style>
</tr>
<?php
}
?>
</table>
<a href="tambahpelanggan.php"> <button class="neon-button">Tambah Pelanggan</button></a><br>
<style>
     .neon-button {
        display: inline-block;
        padding: 8px 10px;
        background-image: linear-gradient(to right, rgb(255,0,0),rgb(0,128,128)   );
        cursor: pointer;
        border-radius: 50px;
        text-align: center;
        color: 	#F4A460;
        font-weight: bold;
        text-decoration: none;
        text-transform: uppercase;
        letter-spacing: 2px;
        border: 1px solid white;
    }

    .neon-button:hover {
        animation: glow 2s linear infinite;
    }

    @keyframes glow {
        0% {
            box-shadow: 5px 5px 20px rgb(255, 0, 255), -5px -5px 20px rgb(255, 0, 255);
        }
    }
</style>
<?php include("layout/header.php"); ?>
</body>