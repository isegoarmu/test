<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="crud.css">
    <title>biodata</title>
</head>
<body>
	
<div class="container">
		<div class="col-lg-15">
			<div class="page-header">
<h2>Pelanggan</h2>
    <a href="tambahpelanggan.php" style="padding :0.4% 0.8%;background-color :red; color :pink; border-radius: 3px; text-decoration : none;">
      Tambah Data Pelanggan</a><br><br>
      <table border = "3" cellspacing="0" width="50%">
      <tr style ="text-align : center;font-color : red ; font-weight : bold; background-color : pink;">
    <td>NO</td>
    <td>Id_Pelanggan</td>
    <td>Nama_Pelanggan</td>
    <td>Alamat</td>
    <td>Telphone</td>
    <td>opsi</td>
</tr>
<?php
include "koneksi.php";
$no = 1;
$select =mysqli_query($koneksi,"select * from pelanggan");
while ($hasil=mysqli_fetch_array($select)){
    ?>
    <tr align = "center">
     <td><?php echo $no++ ?></td>
     <td><?php echo $hasil['id_pelanggan'] ?></td>
     <td><?php echo $hasil['nama_pelanggan'] ?></td>
     <td><?php echo $hasil['alamat'] ?></td>
     <td><?php echo $hasil['tlp']?></td>
      
    <td>
        <a href="editpelanggan.php?id_pelanggan=<?php echo $hasil['id_pelanggan']?>">edit</a>
        <a href="hapuspel.php?id_pelanggan=<?php echo $hasil['id_pelanggan']?>">Hapus</a>
    </td>
    </tr>
<?php } ?>
</table>
<a href="login.php" class='btn btn-warning btn-sm'>KELUAR</a>
</body>
</html>