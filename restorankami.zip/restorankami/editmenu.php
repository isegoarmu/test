<html> 
 
<head> 
<title></title> 
    <?php include("layout/header.php"); ?> 
</head> 
 
 <body> 
     
 <?php 
 if (isset($_GET['error'])) { 
    echo "<p style='color:red;'>" . $_GET['error'] . "</p>"; 
    } 
 
 session_start(); 
 if (!isset($_SESSION['username'])) { 
 header("location:login.php"); 
 } 
 
 ?> 
 <div class="container"> 
 <div class="row"> 
            <div class="col-md-8 mx-auto"> 
                 
 
 <h4>Ubah Data Menu </h4> 
 <?php
	include 'koneksi.php';
	$id = $_GET['x'];
	$data = mysqli_query($koneksi,"select * from menu where id_menu='$id'");
	while($d = mysqli_fetch_array($data)){
		?>
 <form action="edit-m.php" method="POST" enctype="multipart/form-data"> 
 <div class="mb-3"> 
                        <input type="hidden" class="form-control" name="id" value="<?php echo $d['id_menu'];?>">
    </div>
                        <div class="mb-3"> 
                   Nama Menu
                    <input type="text" class="form-control" name="namamenu" value="<?php echo $d['nama_menu'];?>">
                </div> 
                <div class="mb-3"> 
                Kategori
                    <input type="text" class="form-control" name="kategori" value="<?php echo $d['kategori'];?>"> 
                </div> 
                <div class="mb-3"> 
                 Harga
                    <input type="text" class="form-control" name="harga" value="<?php echo $d['harga'];?>"> 
                </div> 
                <button type="submit" class="btn btn-primary">Edit Data</button> 
                </form> 
            </div> 
        </div> 
    </div> 
 <br> 
 </form> 
 <?php
    }
?>
 <?php include("layout/bottom.php");?> 
 </body> 
 </html>