<?php 
include('koneksi.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REFRAN`Z</title>
    <link rel="stylesheet" href="anak.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="image/refranz.png" />
</head>
<body>

    <section id="Home">
        <nav>
            <div class="logo">
                <img src="image/refranz.png">
            </div>

            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="login.php">Keluar</a></li>
            </ul>

            <div class="icon">
                <i class="fa-solid fa-magnifying-glass"></i>
                <i class="fa-solid fa-heart"></i>
                <i class="fa-solid fa-cart-shopping"></i>
            </div>

        </nav>

        <div class="main">

            <div class="men_text">
                <h1>REFRAN`Z<span>RESTO</span><br></h1>
            </div>

            <div class="main_image">
                <img src="image/main_img.png">
            </div>

        </div>

        <p>
        SISTEM INFORMASI : <BR></BR>  
        PROJECT KELOMPOK XII DARI KELAS : 4-SI-C<BR></BR>
        PERANCANGAN DESIGN RESTORAN .PHP .JS .CSS
        </p>

        <div class="main_btn">
            <a href="#">Order Sekarang</a>
            <i class="fa-solid fa-angle-right"></i>
        </div>

    </section>



    <!--About-->

    <div class="about" id="About">
        <div class="about_main">

            <div class="image">
                <img src="image/Food-Plate.png">
            </div>

            <div class="about_text">
                <h1><span>About</span>Us</h1>
                <h3>Project XII</h3>
                <p>
                    Tugas Akhir, Yang di rancang dan di bantu oleh Team REFRAN`Z
                </p>
            </div>

        </div>

        <a href="#" class="about_btn">Order Disini</a>

    </div>



    <!--Menu-->

    <div class="menu" id="Menu">
        <h1><span>Menu</span></h1>

        <div class="menu_box">
            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/buger.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Buger</h2>
                    <p>
                        Asli dari negara Jerman.
                    </p>
                    <h3>Rp.80.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="pesan.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 
            
            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/pasta.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>pasta</h2>
                    <p>
                       Asli Dari Italy
                    </p>
                    <h3>Rp.230.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="pesan.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/lasagna.webp">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>lasagna</h2>
                    <p>
                       Asli Dari Italy
                    </p>
                    <h3>Rp.390.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="pesan.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/chocolate_Drink.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Muamala</h2>
                    <p>
                     Asli Dari negara Indonesian
                    </p>
                    <h3>Rp.700.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="pesan.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/pizza.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>pizza</h2>
                    <p>
                       Asli buatan dari Italy.
                    </p>
                    <h3>Rp.200.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="pesan.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/Hot_dog.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Hot Dog</h2>
                    <p>
                       Asli Buatan America.
                    </p>
                    <h3>Rp.350.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="pesan.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/juse.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Juse</h2>
                    <p>
                        Diproduksi Oleh Negara Jepang.
                    </p>
                    <h3>RP.120.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="menuu.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/biryani.webp">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Biryani</h2>
                    <p>
                        Buatan Asli dari khas Indian.
                    </p>
                    <h3>Rp.500.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="menuu.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/chocolate.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Chocolate</h2>
                    <p>
                        Diproduki oleh negara Spanyol.
                    </p>
                    <h3>Rp.230.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="menuu.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/ice_cream.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Ice Cream</h2>
                    <p>
                      Buatan Asli Dari Amerika.
                    </p>
                    <h3>Rp.440.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="menuu.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/Spanchi.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Spanchi</h2>
                    <p>
                       Makanan Khas dari Spanyol.
                    </p>
                    <h3>Rp.350.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="menuu.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 

            <div class="menu_card">

                <div class="menu_image">
                    <img src="image/sandwich.jpg">
                </div>

                <div class="small_card">
                    <i class="fa-solid fa-heart"></i>
                </div>

                <div class="menu_info">
                    <h2>Sandwich</h2>
                    <p>
                        Makanan asli dari inggris
                    </p>
                    <h3>Rp.200.00</h3>
                    <div class="menu_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <a href="menuu.php.php" class="menu_btn">Order Sekarang</a>
                </div>

            </div> 
            
        </div>

    </div>




    <!--Gallary-->

    <div class="gallary" id="Gallary">
        <h1><span>Order</span></h1>

        <div class="gallary_image_box">
            <div class="gallary_image">
                <img src="image/gallary_1.jpg">

                <h3>Roti Bakar</h3>
                
                <a href="menuu.php" class="gallary_btn">Order Sekarang</a>
            </div>

            <div class="gallary_image">
                <img src="image/gallary_2.jpg">

                <h3>Eskrim Vanila</h3>
                
                <a href="menuu.php" class="gallary_btn">Order Sekarang</a>
            </div>

            <div class="gallary_image">
                <img src="image/gallary_3.jpg">

                <h3>Eskrim Cokelat</h3>
                
                <a href="menuu.php" class="gallary_btn">Order Sekarang</a>
            </div>

            <div class="gallary_image">
                <img src="image/gallary_4.jpg">

                <h3>Kue Kukus Kancang</h3>
                <a href="menuu.php" class="gallary_btn">Order Sekarang</a>
            </div>

            <div class="gallary_image">
                <img src="image/gallary_5.jpg">

                <h3>Pizza</h3>
              
                <a href="menuu.php" class="gallary_btn">Order Sekarang</a>
            </div>

            <div class="gallary_image">
                <img src="image/gallary_6.jpg">

                <h3>Kue Bolu</h3>
                <a href="menuu.php" class="gallary_btn">Order Sekarang</a>
            </div>

        </div>

    </div>




    <!--Review-->

    <div class="review" id="Review">
        <h1><span>Pelanggan</span></h1>

        <div class="review_box">
            <div class="review_card">

                <div class="review_profile">
                    <img src="image/review_1.png">
                </div>

                <div class="review_text">
                    <h2 class="name">NOVARIA</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                    BLABLABLA
                    </p>

                </div>

            </div>

            <div class="review_card">

                <div class="review_profile">
                    <img src="image/review_2.png">
                </div>

                <div class="review_text">
                    <h2 class="name">REIMER PURBA TAMBAK</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        BLABLABLA
                    </p>

                </div>

            </div>

            <div class="review_card">

                <div class="review_profile">
                    <img src="image/review_3.png">
                </div>

                <div class="review_text">
                    <h2 class="name">ELISA</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                        BLABLABLA
                    </p>

                </div>

            </div>

            <div class="review_card">

                <div class="review_profile">
                    <img src="image/review_4.png">
                </div>

                <div class="review_text">
                    <h2 class="name">FRAN`Z</h2>

                    <div class="review_icon">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                    </div>

                    <div class="review_social">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>

                    <p>
                      BLABLABLA
                    </p>

                </div>

            </div>

        </div>

    </div>



    <!--Order-->

    <div class="order" id="Order">
        <h1><span>Pelayanan</span></h1>

        <div class="order_main">

            <div class="order_image">
                <img src="image/order_image.png">
            </div>

            <form action="#">

                <div class="input">
                    <p>Name</p>
                    <input type="text" placeholder="Nama.">
                </div>

                <div class="input">
                    <p>Email</p>
                    <input type="email" placeholder="Example@gmail.com">
                </div>

                <div class="input">
                    <p>Nomor Telephone</p>
                    <input placeholder="+62">
                </div>

                <div class="input">
                    <p>Transaksi</p>
                    <input type="number" placeholder="Pembayaran">
                </div>

                <div class="input">
                    <p>Nama Menu</p>
                    <input placeholder="Menu">
                </div>

                <div class="input">
                    <p>Alamat</p>
                    <input placeholder="Alamat">
                </div>

                <a href="#" class="order_btn">Order Disini</a>

            </form>

        </div>

    </div>



    <!--Team-->

    <div class="team">
        <h1><span>Team</span></h1>

        <div class="team_box">
            <div class="profile">
                <img src="image/fransisco.jpg">

                <div class="info">
                    <h2 class="name">Designner</h2>
                    <p class="bio">FRANSISCO JULIUS MARPAUNG.</p>

                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

           

            <div class="profile">
                <img src="image/re.jpg">

                <div class="info">
                    <h2 class="name">Designner</h2>
                    <p class="bio">Reimer Fernando Purba.</p>

                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

            <div class="profile">
                <img src="image/frans.jpg">

                <div class="info">
                    <h2 class="name">Designner</h2>
                    <p class="bio">Jhon Frans E.D.L Sitorus.</p>

                    <div class="team_icon">
                        <i class="fa-brands fa-facebook-f"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-instagram"></i>
                    </div>

                </div>

            </div>

        </div>

    </div>



    <!--Footer-->

    <footer>
        <div class="footer_main">

            <div class="footer_tag">
                <h2>Lokasi</h2>
                <p>Medan</p>
                <p>Jakarta</p>
                <p>Surabaya</p>
                <p>Jogja</p>
                <p>Bali</p>
            </div>

            <div class="footer_tag">
                <h2>Quick Link</h2>
                <p>Home</p>
                <p>About & Contact</p>
                <p>Menu Makanan/Minuman</p>
                <p>Admin Panel</p>
                <p>Pemesanan</p>
            </div>

            <div class="footer_tag">
                <h2>Contact</h2>
                <p>+62 88212412722</p>
                <p>+62 821-1159-4116</p>
                <p>+62 812-6231-7300</p>
                <p>REFRANZ@gmail.com</p>
                <p>REFRANZRESTO@example.com</p>
            </div>

            <div class="footer_tag">
                <h2>Service</h2>
                <p>Fast Delivery</p>
                <p>Easy Payments</p>
                <p>24 x 7 Service</p>
            </div>

            <div class="footer_tag">
                <h2>Follows</h2>
                <i class="fa-brands fa-facebook-f"></i>
                <i class="fa-brands fa-twitter"></i>
                <i class="fa-brands fa-instagram"></i>
                <i class="fa-brands fa-linkedin-in"></i>
            </div>

        </div>

        <p class="end">Design by<span><i class="fa-solid fa-face-grin"></i> PROJECT  XII</span></p>

    </footer>



    
</body>
</html>
