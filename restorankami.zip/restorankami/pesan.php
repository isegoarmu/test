<!doctype html>
<html lang="en">
<head>
<title>Halaman Pesan</title>
<?php include("layout/header.php"); ?>
<link rel="stylesheet" href="panel.css">
<link rel="icon" href="image/refranz.png" />
</head>
<body>
<?php include("menu.php"); ?>
<?php
session_start();
if (!isset($_SESSION['username'])) {
header("location:login.php");
exit;
}
if (isset($_GET['pesan'])) {
echo $_GET['pesan'];
}
?>
<table border = "1" cellspacing="0" width="240%">
<tr>
<th><span class="material-symbols-outlined">verified</span>ID Pesan</th>
<th><span class="material-symbols-outlined">verified</span>ID Menu</th>
<th><span class="material-symbols-outlined">redeem</span>Qty</th>
<th><span class="material-symbols-outlined">payments</span>Total Sub</th>
<th><span class="material-symbols-outlined">verified</span>ID Pelanggan</th>
<th><span class="material-symbols-outlined">date_range</span>tglpesan</th>
<th><span class="material-symbols-outlined">deck</span>Meja</th>
<th><span class="material-symbols-outlined">menu_book</span>Opsi</th>
</tr>
<?php
include('koneksi.php');
$sql = "SELECT * FROM pesan";
$aksi = mysqli_query($koneksi, $sql);
while ($data = mysqli_fetch_assoc($aksi)) {
?>
<tr>
<td><?php echo $data['id_pesan']; ?></td>
<td><?php echo $data['id_menu']; ?></td>
<td><?php echo $data['qty']; ?></td>
<td><?php echo $data['sub_total']; ?></td>
<td><?php echo $data['id_pelanggan']; ?></td>
<td><?php echo $data['tgl_pesan']; ?></td>
<td><?php echo $data['meja']; ?></td>
<td>
<a href="editpesan.php?id_pesan=<?php echo $data['id_pesan']; ?>">
<span class="material-symbols-outlined">
add_shopping_cart
</span>
    </a>
    <a href="hapuspesan.php?id_pesan=<?php echo $data['id_pesan']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">
    <span class="material-symbols-outlined">
delete
</span>

<a href="tambahpesan.php"><button class="neon-button">Tambah Pesan</button></a><br>
                    </a>
                </td>
<style>
    .delete-button {
        border: 1px solid red;
    }
    .edit-button {
        border: 1px solid blue;
    }
</style>
</tr>
<?php
}
?>
</table>
<style>
     .neon-button {
        display: inline-block;
        padding: 8px 10px;
        background-image: linear-gradient(to right, rgb(18, 194, 233), rgb(196, 113, 237), rgb(246, 79, 89));
        cursor: pointer;
        border-radius: 50px;
        text-align: center;
        color: #fff;
        font-weight: bold;
        text-decoration: none;
        text-transform: uppercase;
        letter-spacing: 2px;
        border: 1px solid white;
    }

    .neon-button:hover {
        animation: glow 2s linear infinite;
    }

    @keyframes glow {
        0% {
            box-shadow: 5px 5px 20px rgb(93, 52, 168), -5px -5px 20px rgb(93, 52, 168);
        }

        50% {
            box-shadow: 5px 5px 20px rgb(81, 224, 210), -5px -5px 20px rgb(81, 224, 210);
        }}
</style>
<?php include("layout/header.php"); ?>
</body>