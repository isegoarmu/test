<!doctype html>
<html lang="en">
<head>
<title>Halaman Pesan</title>
<?php include("layout/header.php"); ?>
</head>
<body>
<?php include("menu.php"); ?>
<?php
session_start();
if (!isset($_SESSION['username'])) {
header("location:login.php");
exit;
}
if (isset($_GET['pesan'])) {
echo $_GET['pesan'];
}
?>
<table class="table">
<tr>
<th>ID Pesan</th>
<th>ID Menu</th>
<th>Qty</th>
<th>Total Sub</th>
<th>ID Pelanggan</th>
<th>tglpesan</th>
<th>Meja</th>
</tr>
<?php
include('koneksi.php');
$sql = "SELECT * FROM pesan";
$aksi = mysqli_query($koneksi, $sql);
while ($data = mysqli_fetch_assoc($aksi)) {
?>
<tr>
<td><?php echo $data['id_pesan']; ?></td>
<td><?php echo $data['id_menu']; ?></td>
<td><?php echo $data['qty']; ?></td>
<td><?php echo $data['sub_total']; ?></td>
<td><?php echo $data['id_pelanggan']; ?></td>
<td><?php echo $data['tgl_pesan']; ?></td>
<td><?php echo $data['meja']; ?></td>
<td>
<a href="editpesan.php?id_pesan=<?php echo $data['id_pesan']; ?>">
<span class="material-symbols-outlined">
add_shopping_cart
</span>
    </a>
    <a href="hapuspesan.php?id_pesan=<?php echo $data['id_pesan']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">
    <span class="material-symbols-outlined">
delete
</span>
                    </a>
                </td>
<style>
    .delete-button {
        border: 1px solid red;
    }
    .edit-button {
        border: 1px solid blue;
    }
</style>
</tr>
<?php
}
?>
</table>
<a href="tambahpesan.php"><button class="neon-button">Tambah Pesan</button></a><br>
<style>
     .neon-button {
        display: inline-block;
        padding: 8px 10px;
        background-image: linear-gradient(to right, rgb(18, 194, 233), rgb(196, 113, 237), rgb(246, 79, 89));
        cursor: pointer;
        border-radius: 50px;
        text-align: center;
        color: #fff;
        font-weight: bold;
        text-decoration: none;
        text-transform: uppercase;
        letter-spacing: 2px;
        border: 1px solid white;
    }

    .neon-button:hover {
        animation: glow 2s linear infinite;
    }

    @keyframes glow {
        0% {
            box-shadow: 5px 5px 20px rgb(93, 52, 168), -5px -5px 20px rgb(93, 52, 168);
        }

        50% {
            box-shadow: 5px 5px 20px rgb(81, 224, 210), -5px -5px 20px rgb(81, 224, 210);
        }}
</style>
<?php include("layout/header.php"); ?>
</body>