<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">REFRAN`Z RESTO</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li class="active"><a href="about.php">About</a></li>
      <li class="active"><a href="contact.php">Contacts</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Menu<span class="caret"></span></a>
        <ul class="dropdown-menu">
        <li><a href="menu.php">Menu</a></li>
          <li><a href="pelanggan.php">Pelanggan</a></li>
          <li><a href="pesan.php">Pesan</a></li>
          <li><a href="petugas.php">Petugas</a></li>
        </ul>
      </li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
    <li><a href="admin.php"><span class="glyphicon glyphicon-user"></span> User</a></li>  
    <li><a href="admin.php"><span class="glyphicon glyphicon-user"></span> Register</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>